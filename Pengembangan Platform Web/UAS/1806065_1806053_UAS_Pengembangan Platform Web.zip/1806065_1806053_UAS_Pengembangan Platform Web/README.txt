Petunjuk Penggunaan Aplikasi
1. Download folder sflix.zip
2. Extract folder sflix
3. Pindahkan ke xampp/htdocs/sflix
4. Buka XAMPP lalu Start Module Apache & MySQL
5. Import database dari folder sflix/db/sflix.sql
6. Buka localhost/sflix

Akun untuk login ke admin (Upload film baru) 
Username: admin
Password: admin

Username: renaldy
Password: renaldy

Username: fauzan
Password: fauzan

Software Pendukung
- XAMPP Control Panel v3.2.4
- VSCode
- PHP Version 7